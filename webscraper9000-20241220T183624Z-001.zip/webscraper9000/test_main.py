import json
import unittest
from main import parse_price, calculate_lease_payment, calculate_finance_payment, map_to_known_color, main

class TestWebScraper(unittest.TestCase):

    def test_parse_price(self):
        self.assertEqual(parse_price("$19,999"), 19999)
        self.assertEqual(parse_price("$19,999 - $20,999"), 19999)
        self.assertEqual(parse_price("N/A"), 0)

    def test_calculate_lease_payment(self):
        self.assertAlmostEqual(calculate_lease_payment(30000, 3000), 484.1666667, places=4)

    def test_calculate_finance_payment(self):
        self.assertAlmostEqual(calculate_finance_payment(30000, 3000), 532.131407, places=4)

    def test_map_to_known_color(self):
        self.assertEqual(map_to_known_color((85, 96, 110)), 'Crystal Black Pearl')
        self.assertEqual(map_to_known_color((190, 190, 190)), 'Lunar Silver Metallic')

    def test_main_search_crv_hybrid_2025(self):
        # Simulate a Lambda event for a 2025 Honda CR-V Hybrid with finance payment type
        test_event = {
            "pathParameters": {
                "model": "cr-v-hybrid-2025",
                "paymentType": "finance"
            },
            "queryStringParameters": {}
        }
        context = {}  # Dummy context
        response = main(test_event, context)
        self.assertEqual(response['statusCode'], 200)
        cars = json.loads(response['body'])
        self.assertIsInstance(cars, list)
        self.assertGreater(len(cars), 0)
        for car in cars:
            self.assertIn('finance_price', car)

if __name__ == "__main__":
    unittest.main()
